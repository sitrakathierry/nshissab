declare namespace cptable {
  export var utils: any;
}